import requests
from bs4 import BeautifulSoup

# Function to extract data
def extract_data(url):
    # Send a request to the webpage
    response = requests.get(url)
    
    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        # Parse the webpage content
        soup = BeautifulSoup(response.content, 'html.parser')
        
        # Example: Extract all the titles (h2) from the page
        titles = soup.find_all('h2')
        for i, title in enumerate(titles, 1):
            print(f"{i}. {title.get_text()}")
            
        # Example: Extract all the hyperlinks
        links = soup.find_all('a')
        for link in links:
            href = link.get('href')
            text = link.get_text()
            print(f"Link: {text} -> {href}")
    else:
        print(f"Failed to retrieve data. Status code: {response.status_code}")

# URL to scrape
while True:
    url = input("Enter the URL/Link : ")
    extract_data(url)
    exe=input("Do you want to exit...? (y/n) : ").lower()
    if exe=='y':
        exit(0)
    else:
        continue