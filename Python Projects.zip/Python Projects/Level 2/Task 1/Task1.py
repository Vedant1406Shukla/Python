#Task 1 Guessing Game#
import random
def guess_game():
    num=random.randint(1,100)
    while True:
        guess=int(input("Enter the number (1-100) : "))
        if guess<1 or guess>100:
            print("Invalid Guess, Out of Range ")
        elif guess==num:
            print("Congratulations !! You guessed  the right number ",num)
            x=input("Do you want to play again ..?(Y/N) : ")
            if x=='Y':
                guess_game()
            elif x=='N':
                exit()
        elif guess>num:
            print("Too High ! ")
        elif guess<num:
            print("Too Low ! ")
        g=input("Do you want to guess again ..?(Y/N) : ")
        if g=='Y':
            guess_game()
        elif g=='N':
            exit()
    
guess_game()  