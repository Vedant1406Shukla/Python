#Task 4 Fibonacci Sequence
def fibonacci(terms):
    list=[0,1]
    for i in range(0,terms-2):
        list.append(list[i]+list[i+1])

    return list

x=int(input("Enter the number of terms : "))
if x>1:
    fib_seq=fibonacci(x)
    print("Fibonacci Sequence -",fib_seq)
else:
    print("Invalid term ")