#Task 2 Number Guesser
import random
def guess_game(min,max):
    num=random.randint(min,max)
    while True:
        guess=int(input(f"Enter the number ({min}-{max}) : "))
        if guess<min or guess>max:
            print("Invalid Guess, Out of Range ")
        elif guess==num:
            print("Congratulations !! You guessed  the right number ",num)
            x=input("Do you want to play again ..?(Y/N) : ")
            if x=='Y':
                guess_game(min,max)
            else:
                exit()
        elif guess>num:
            print("Too High ! ")
        elif guess<num:
            print("Too Low ! ")
        g=input("Do you want to guess again ..?(Y/N) : ")
        if g=='Y':
            guess_game(min,max)
        else:
            exit()

min=int(input("Enter minimum value for range : ")) 
max=int(input("Enter maximum value for range : "))   
guess_game(min,max)  