#Task 4 Calculator Program
def add(a,b):
    return (a+b)
def subtract(a,b):
    return (a-b)
def multiply(a,b):
    return (a*b)
def divide(a,b):
   if b!=0:
       return (a/b)
   else:
       print("Division by zero error...")

def modulo(a,b):
    return (a%b)

while True:
    x=int(input("Enter first number : "))
    y=int(input("Enter second number : "))
    op=input("Enter an operator (+,-,*,/,%) : ")
    if op=='+':
        print(x,op,y,"=",add(x,y))
    elif op=='-':
        print(x,op,y,"=",subtract(x,y))
    elif op=='*':
        print(x,op,y,"=",multiply(x,y))
    elif op=='/':
        print(x,op,y,"=",divide(x,y))
    elif op=='%':
        print(x,op,y,"=",modulo(x,y))
    else:
        print("Invalid Operator")

    s=input("Exit (Y/N) ? : ")
    if s=='Y':
        break
    else:
        continue