#Task 5 : Palindrome Checker
def reverse_string1(inp_str):
      return inp_str[::-1]

inp_str=input("Enter a string : ")
if inp_str==reverse_string1(inp_str):
    print(inp_str," is a Palindrome String")
else:
    print(inp_str," is not a Palindrome String")    