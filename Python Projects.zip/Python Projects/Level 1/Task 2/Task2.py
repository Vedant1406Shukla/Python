#Task 2 :Temperature Conversion
def celsius_to_fahrenheit(c):
    f=9*c/5+32
    return f

def fahrenheit_to_celsius(f):
    c=5*(f-32)/9
    return c

temperature=float(input("Enter the temperature value :"))
unit=input("Enter the unit (C/F) : ").upper()
if unit=='C':
    print(temperature,unit," is equal to ",celsius_to_fahrenheit(temperature),'F')
elif unit=='F':
    print(temperature,unit," is equal to ",fahrenheit_to_celsius(temperature),'C')
else:
    print("Invalid Unit")
