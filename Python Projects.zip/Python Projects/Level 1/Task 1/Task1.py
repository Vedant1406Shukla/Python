#Task 1 : String Reversal
def reverse_string1(inp_str):    # Using loop
  rev=""
  for ch in inp_str:
    rev= ch+rev
  return rev    

def reverse_string2(inp_str):   # Using Slicing Technique
  return inp_str[::-1]

str=input("Enter a string : ")
rev_str1=reverse_string1(str)
print("Reverse String :",rev_str1) 

str=input("Enter a string : ")
rev_str2=reverse_string2(str)
print("Reverse String :",rev_str2)
